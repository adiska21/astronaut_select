from flask import Flask

app = Flask(__name__)


@app.route('/')
@app.route('/home')
def home():
    return """<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Миссия Колонизация Марса</title>
                  </head>
                  <body>
                    <h1>Миссия Колонизация Марса</h1>
                  </body>
                </html>"""


@app.route('/index')
def index():
    return """<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Миссия Колонизация Марса</title>
                  </head>
                  <body>
                    <h1>И на Марсе будут яблони цвести!</h1>
                  </body>
                </html>"""


@app.route("/promotion")
def promotion():
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous">
                    <title>Миссия Колонизация Марса</title>
                  </head>
                  <body>
                    <h1>И на Марсе будут яблони цвести!</h1>
                    <div class="alert alert-primary" role="alert">
                      Человечество вырастает из детства.<br>
                      Человечеству мала одна планета.<br>
                      Мы сделаем обитаемыми безжизненные пока планеты.<br>
                      И начнем с Марса!<br>
                      Присоединяйся!
                    </div>
                  </body>
                </html>'''


@app.route('/image_mars')
def image_mars():
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                  </head>
                  <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="https://cs6.pikabu.ru/avatars/1126/v1126093-1625455561.jpg" 
                    alt="здесь должна была быть картинка, но не нашлась">
                    <h4>Так вот она какая, красная планета!<h4>
                    <div class="alert alert-primary" role="alert">
                    </div>
                  </body>
                </html>'''


@app.route('/promotion_image')
def promotion_image():
    return '''<!doctype html>
              <html lang="en">
                <head>
                  <meta charset="UTF-8">
                  <title>promotion_image</title>
                  <link rel="stylesheet" href="static/css/style.css">
                </head>
                  <body>
                    <h1 style="color: #FF0000">Жди нас, Марс</h1>
                    <img src="static/img/mars-img.png" width="500px" height="300px">
                    <div class="dark-grey">Человечество вырастает из детства.<br></div>
                    <div class="green">Человечеству мала одна планета.<br></div>
                    <div class="grey">Мы сделаем обитаемыми безжизненные пока планеты.<br></div>
                    <div class="yellow">И начнем с Марса!<br></div>
                    <div class="red">Присоединяйся!</div>
                  </body>
              </html>'''


@app.route("/astronaut_selection")
def astronaut_selection():
    return '''<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>Отбор Астронавтов</title>
                </head>
                <body>
                    <h1 align="center" style="margin:5px">Анкета претендента</h1>
                    <h2 align="center" style="margin:5px">На участие в миссии</h2>
                    <div style="background-color:#ffdab9; width:25%; height:50%; border:1px solid; margin:0 37.5% 0 37.5%; border-radius: 4px">
                        <div style="margin:5px"><input placeholder="Введите фамилию"  size="30"></div>
                        <div style="margin:5px"><input placeholder="Введите имя" size="30"></div>
                        <div style="margin-top:10px; margin-left:5px"><input placeholder="Введите электронную почту" size="30"></div>
                        <div style="margin-top:20px">Какое у вас образование?</div>
                        <div>
                            <select>
                                <option value="s1">Детский сад</option>
                                <option value="s2">Начальное</option>
                                <option value="s2">Среднее</option>
                                <option value="s2">Среднее оконченное</option>
                                <option value="s2">Высшее</option>
                                <option value="s2">Высшее проффесионнальное</option>
                            </select>
                        </div>
                        <div style="margin-top:20px">
                            <div>С какими проффесиями вы ознакомлены?</div>
                            <div>
                                <input type="radio" id="Инженер-исследователь" value="Инженер-исследователь">
                                <label for="Инженер-исследователь">Инженер-исследователь</label>
                            </div>
                            <div>
                                <input type="radio" id="Инженер-строитель" value="Инженер-строитель">
                                <label for="Инженер-строитель">Инженер-строитель</label>
                            </div>
                            <div>
                                <input type="radio" id="Пилот" value="Пилот">
                                <label for="Пилот">Пилот</label>
                            </div>
                            <div>
                                <input type="radio" id="Метеоролог" value="Метеоролог">
                                <label for="Метеоролог">Метеоролог</label>
                            </div>
                            <div>
                                <input type="radio" id="Инженер по жизнеобеспечению" value="Инженер по жизнеобеспечению">
                                <label for="Инженер по жизнеобеспечению">Инженер по жизнеобеспечению</label>
                            </div>
                            <div>
                                <input type="radio" id="Инженер по радиационной зашите" value="Инженер по радиационной зашите">
                                <label for="Инженер по радиационной зашите">Инженер по радиационной зашите</label>
                            </div>
                            <div>
                                <input type="radio" id="Врач" value="Врач">
                                <label for="Врач">Врач</label>
                            </div>
                            <div>
                                <input type="radio" id="Экзобиолог" value="Экзобиолог">
                                <label for="Экзобиолог">Экзобиолог</label>
                            </div>
                        </div>
                        <div style="margin:20px">
                            <div>Какой ваш пол?</div>
                            <div>
                            <input type="radio" id="Муж">
                            <label for="Муж">Муж</label>
                            </div>
                            <div>
                            <input type="radio" id="Жен">
                            <label for="Жен">Муж</label>
                            </div>
                        </div>
                        <div style="margin:20px">
                            <div>Почему вы хотите принять участие в Мисси?</div>
                            <textarea rows="7" style="width:90%"></textarea>
                        </div>
                        <div style="margin:20px">
                            <div>Приложите фотографию</div>
                            <div>
                                <input type="file" value="файл не выбран">
                            </div>
                        </div>
                        <div style="margin:20px">
                            <input type="radio" id="Готовы остаться на Марсе?">
                            <label for="Готовы остаться на Марсе?">Готовы остаться на Марсе?</label>
                        </div>
                        <div style="margin:20px">
                            <input type="button" value="Отправить">
                        </div>
                    </div>
                </body>
                </html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')